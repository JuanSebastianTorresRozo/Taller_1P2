/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package co.edu.udes.tallercine2;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Sebas
 */
public class TallerCine2 {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        ArrayList<Sala> salas = new ArrayList<>();
        ArrayList<Ticket> tickets = new ArrayList<>();
        ArrayList<Movie> movies = new ArrayList<>();
        ArrayList<Employee> employees = new ArrayList<>();
        ArrayList<Customer> customers = new ArrayList<>();
        ArrayList<Confectionery> confectionerys = new ArrayList<>();

        boolean salir = false;

        while (!salir) {
            int menu = mostrarMenu(entrada);
            switch (menu) {

                case 1:
                    if (movies.size() == 0) {
                        System.out.println("No puedes agregar una sala , sin antes no agregar una pelicula");
                        break;
                    } else {
                        agregarSala(entrada, salas, movies);
                        break;
                    }
                case 2:
                    if (salas.size() == 0) {
                        System.out.println("No puedes agregar un ticket , sin antes no agregar una sala");
                        break;
                    } else {
                        agregaTicket(entrada, tickets, salas);
                        break;
                    }
                case 3:
                    agregaPelicula(entrada, movies);
                    break;
                case 4:
                    if (salas.size() == 0) {
                        System.out.println("No puedes agregar un empleado , sin antes no agregar una sala o  la confiteria");
                        break;
                    } else {
                        agregaEmployee(entrada, employees, salas);
                        break;
                    }
                case 5:
                    if (confectionerys.size() == 0) {

                        System.out.println("No puedes agregar un cliente sin una confiteria");
                        break;
                    } else {
                        agregaCustomer(entrada, customers, salas);
                        break;
                    }
                case 6:
                    if (employees.size() == 0) {
                        System.out.println("No puedes agregar confiteria sin empleados");
                        break;
                    } else {

                        agregarConfectionery(entrada, confectionerys, employees);
                        break;

                    }
                case 7:
                    System.out.println(salas.toString());
                    System.out.println(tickets.toString());
                    System.out.println(movies.toString());
                    System.out.println(employees.toString());
                    System.out.println(customers.toString());
                    System.out.println(confectionerys.toString());
            }

        }
    }

    public static int mostrarMenu(Scanner entrada) {
        System.out.println("Bienvenido al Sistema");
        System.out.println("Seleccione un menú:");
        System.out.println("1. Salas");
        System.out.println("2. Tickets");
        System.out.println("3. Peliculas");
        System.out.println("4. Empleado");
        System.out.println("5. Cliente");
        System.out.println("6. Confiteria");
        System.out.println("7. Mostrar");
        System.out.println("8. Salir");
        return entrada.nextInt();
    }

    public static void agregarSala(Scanner entrada, ArrayList<Sala> salas, ArrayList<Movie> movies) {
        System.out.println("Agregue la capacidad de la Sala: ");
        int capacity = entrada.nextInt();
        System.out.println("Agregue el número de sala: ");
        int number_hall = entrada.nextInt();
        entrada.nextLine(); // Limpiar el buffer del scanner
        for (Sala sala : salas) {
            if (sala.getNumber_hall() == number_hall) {
                System.out.println("El número de sala ya existe. Ingrese otro número de sala.");
                return;
            }
        }
        System.out.println("Peliculas disponibles");
        for (int i = 0; i < movies.size(); i++) {
            System.out.println((i + 1) + " " + movies.get(i).getName());
        }
        System.out.println("Ingrese el numero de la pelicula deseada: ");
        int selectMovie = entrada.nextInt();
        entrada.nextLine(); // Limpiar el buffer del scanner

        String movieUser;
        movieUser = movies.get(selectMovie - 1).getName();

        salas.add(new Sala(capacity, number_hall, movieUser));
    }

    public static  ArrayList<Movie> agregaPelicula(Scanner entrada, ArrayList<Movie> movies) {
        System.out.println("Agregue el título de la película:");
        String name = entrada.next();
        entrada.nextLine();
        System.out.println("Agregue la hora en formato HH:mm");
        String duration = entrada.next();

        LocalTime localTime;
        try {
            localTime = LocalTime.parse(duration);
        } catch (DateTimeParseException e) {
            System.out.println("Error: Formato de hora incorrecto. Ingrese la hora en formato HH:mm.");
            return movies; // Retornar el arreglo sin agregar la nueva película
        }

        System.out.println("Agregue la fecha de lanzamiento:");
        String release_Date = entrada.next();

        LocalDate localDate;
        try {
            localDate = LocalDate.parse(release_Date, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        } catch (DateTimeParseException e) {
            System.out.println("Error: Formato de fecha incorrecto. Ingrese la fecha en formato DD/MM/AAAA.");
            return movies; // Retornar el arreglo sin agregar la nueva película
        }

        System.out.println("Agregue la fecha hasta que estará disponible:");
        String available_dates = entrada.next();

        LocalDate localDate2;
        try {
            localDate2 = LocalDate.parse(available_dates, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        } catch (DateTimeParseException e) {
            System.out.println("Error: Formato de fecha incorrecto. Ingrese la fecha en formato DD/MM/AAAA.");
            return movies; // Retornar el arreglo sin agregar la nueva película
        }

        movies.add(new Movie(name, duration, release_Date, available_dates));

        return movies;
    }

     public static void agregaTicket(Scanner entrada, ArrayList<Ticket> tickets, ArrayList<Sala> sala) {
    System.out.println("Seleccione la sala: ");
for (int i = 0; i < sala.size(); i++) {
    System.out.println((i + 1) + ". Sala " + sala.get(i).getNumber_hall() + ": " + sala.get(i).getMovie());
}

int selectedHall = entrada.nextInt();
entrada.nextLine();

Sala selectedSala = sala.get(selectedHall - 1);
String selectedMovie = selectedSala.getMovie();

System.out.println("Seleccione el asiento (letra y número): ");
String seat = entrada.nextLine();

double ticketPrice = 0.0;
boolean validPrice = false;
while (!validPrice) {
    System.out.println("Ingrese el precio del boleto: ");
    try {
        ticketPrice = Double.parseDouble(entrada.nextLine());
        validPrice = true;
    } catch (NumberFormatException e) {
        System.out.println("Por favor, ingrese un número válido.");
    }
}

if (selectedSala.getTickets().size() >= selectedSala.getCapacity()) {
    System.out.println("Lo siento, la sala está llena. No se puede agregar más tickets.");
}

Ticket newTicket = new Ticket(selectedMovie,ticketPrice,seat,selectedHall);
selectedSala.getTickets().add(newTicket);
tickets.add(newTicket);

}

    public static ArrayList<Employee> agregaEmployee(Scanner entrada, ArrayList<Employee> employees, ArrayList<Sala> salas) {
        System.out.println("Agregue el nombre del empleado: ");
        String name = entrada.next();

        System.out.println("Agregue el id del empleado: ");
        String id = entrada.next();

        System.out.println("Agregue el salario del empleado: ");
        double salary = entrada.nextDouble();

        System.out.println("Agregue el area de trabajo del empleado: ");
        String works_area = entrada.next();

        employees.add(new Employee(name, id, salary, works_area));

        return employees;
    }

    public static ArrayList<Customer> agregaCustomer(Scanner entrada, ArrayList<Customer> customers, ArrayList<Sala> salas) {
        System.out.println("Agregue el nombre del cliente: ");
        String name = entrada.next();

        System.out.println("Agregue el id del empleado: ");
        String id = entrada.next();

        System.out.println("Agregue el numero del empleado: ");
        String cell_number = entrada.next();

        customers.add(new Customer(name, id, cell_number));

        return customers;
    }

    public static ArrayList<Confectionery> agregarConfectionery(Scanner entrada, ArrayList<Confectionery> confectionerys, ArrayList<Employee> employees) {

        System.out.println("Agregar productos a la confiteria:");

        System.out.println("Que productos va a ingresar: ");
        String products = entrada.next();

        System.out.println("Que precios van a tener los productos: ");
        double price = entrada.nextDouble();
        entrada.nextLine();

        confectionerys.add(new Confectionery(price, products));
        return confectionerys;

    }
}
